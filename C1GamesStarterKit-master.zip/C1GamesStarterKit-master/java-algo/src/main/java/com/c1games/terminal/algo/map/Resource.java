package com.c1games.terminal.algo.map;

/**
 * A type of resource which the player accumulates and can spend on moves.
 */
public enum Resource {
    Cores,
    Bits,
}
