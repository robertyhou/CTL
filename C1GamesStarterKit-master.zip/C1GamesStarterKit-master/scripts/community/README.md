# Community contributions

This folder contains community created scripts. Each is self documented and has been approved by C1, but 
are not guaranteed to work across any or all of our supported environments, now or in the future.

If you want to add a script here, or update an existing one, we encourage you to make a pull request to 
the C1GamesStarterKit repository.
